## 🚀 AXIOM-7 on Vercel - Complete Setup Guide

### Project Structure
```
axiom7/
├── index.html              (Frontend - the game)
├── api/
│   └── chat.js            (Backend serverless function)
├── vercel.json            (Vercel config)
├── .env.local             (Local testing - NOT in git)
└── .gitignore
```

---

## **Step 1: Prepare Your Git Repository**

```bash
# Create a new directory
mkdir axiom7
cd axiom7

# Initialize git
git init

# Create .gitignore
echo ".env.local" >> .gitignore
echo "node_modules/" >> .gitignore
```

Then copy the files:
- `index.html` → root
- `api/chat.js` → `api/chat.js`
- `vercel.json` → root
- `.env.local` → root (don't commit this)
- `.gitignore` → root

---

## **Step 2: Test Locally (Optional)**

```bash
# Install Vercel CLI
npm install -g vercel

# Test locally with your actual key
# Edit .env.local and add: GROQ_API_KEY=gsk_your_actual_key

# Run local server
vercel dev

# Visit http://localhost:3000
```

---

## **Step 3: Deploy to Vercel**

### **Option A: Via Vercel Dashboard (Easiest)**

1. Go to [vercel.com](https://vercel.com)
2. Sign up / Login
3. Click "New Project"
4. Select your GitHub repo with this code
5. Click "Import"
6. Go to **Settings → Environment Variables**
7. Add:
   - Name: `GROQ_API_KEY`
   - Value: Your actual Groq key
8. Click **Deploy**

### **Option B: Via CLI**

```bash
# Login to Vercel
vercel login

# Deploy
vercel

# Follow the prompts, then add env var:
vercel env add GROQ_API_KEY
# Paste your key when prompted

# Deploy again to use the env var
vercel --prod
```

---

## **Step 4: Set Your Environment Variable**

**On Vercel Dashboard:**
1. Go to your project
2. Settings → Environment Variables
3. Add new variable:
   - **Name:** `GROQ_API_KEY`
   - **Value:** `gsk_your_actual_key_here`
   - **Environments:** Check all (Production, Preview, Development)
4. Save

**Redeploy after adding the env var:**
```bash
vercel --prod
```

---

## **Step 5: Test Your Live Game**

Visit your Vercel URL (like `https://axiom7.vercel.app`)

The game should:
- ✅ Auto-connect to backend
- ✅ Load the intro story
- ✅ Accept commands and riddle answers
- ✅ Progress through levels

---

## **Troubleshooting**

### **"Backend connection failed"**
- Check Vercel logs: Dashboard → Deployments → Function logs
- Verify `GROQ_API_KEY` is set in Environment Variables
- Redeploy after adding the env var

### **"Internal server error"**
- Go to Vercel dashboard → Logs
- Look for error details
- Common: Key not set or expired

### **CORS errors**
- The `api/chat.js` already handles CORS headers
- Should work fine

### **Check Logs**
```bash
# View live logs
vercel logs https://your-project.vercel.app

# Or see them in dashboard → Deployments → Function logs
```

---

## **Project Structure Reference**

```javascript
// Your frontend (index.html) automatically:
// - Detects localhost: uses http://localhost:3000/api/chat
// - On Vercel: uses /api/chat (same domain)

// api/chat.js runs as serverless function at:
// https://your-project.vercel.app/api/chat
```

---

## **Security Checklist**

✅ `.env.local` is in `.gitignore` (never commit your key)  
✅ API key only on Vercel environment variables  
✅ Frontend never sees the raw key  
✅ CORS headers configured in `api/chat.js`  

---

## **Custom Domain (Optional)**

1. Go to Vercel dashboard → Settings → Domains
2. Add your domain
3. Follow DNS setup instructions
4. Your game will be at your custom domain!

---

## **Update Your Code Later**

```bash
# Make changes locally
# Edit index.html or api/chat.js

# Push to git
git add .
git commit -m "Update game logic"
git push origin main

# Vercel auto-deploys! No extra steps needed.
```

---

## **Need Help?**

- Vercel docs: https://vercel.com/docs
- Groq API: https://console.groq.com
- Check function logs in Vercel dashboard

**Your game is now live! 🎮**
